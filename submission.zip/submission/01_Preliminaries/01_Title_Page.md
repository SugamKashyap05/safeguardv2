
<div align="center">

# SAFEGUARD: AI-POWERED CHILD SAFETY PLATFORM

<br>

**A CAPSTONE PROJECT REPORT**

<br>

*Submitted in partial fulfillment of the requirements for the award of the degree of*

<br>

**BACHELOR OF TECHNOLOGY**

IN

**COMPUTER SCIENCE AND ENGINEERING**

<br>

*Submitted By*

**[Your Name]**  
**Reg. No.: [Your Reg No]**

<br>

*Under the Guidance of*

**[Mentor Name]**  
**[Mentor Designation]**

<br>
<br>

![LPU Logo](https://upload.wikimedia.org/wikipedia/en/9/9f/Lovely_Professional_University_logo.png)

<br>
<br>

**SCHOOL OF COMPUTER SCIENCE AND ENGINEERING**  
**LOVELY PROFESSIONAL UNIVERSITY**  
**PHAGWARA, PUNJAB (INDIA)**  
**[Month, Year]**

</div>
