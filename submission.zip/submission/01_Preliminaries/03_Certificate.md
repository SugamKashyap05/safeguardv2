
# CERTIFICATE

This is to certify that the Capstone Project Report entitled **"SafeGuard: AI-Powered Child Safety Platform"**, submitted by **[Your Name]** (Reg. No. [Your Reg No]), to the **School of Computer Science and Engineering, Lovely Professional University**, Phagwara, for the award of the degree of **Bachelor of Technology in Computer Science and Engineering**, is a bona fide record of research work carried out by him/her under my supervision.

The contents of this report, in full or in parts, have not been submitted to any other Institute or University for the award of any degree or diploma.

<br>
<br>
<br>
<br>

**Signature of Mentor**

**[Mentor Name]**  
**[Designation]**  
**School of Computer Science and Engineering**  
**Lovely Professional University**  
**Phagwara, Punjab**

<br>
<br>

**Date:** [DD/MM/YYYY]
