
# DECLARATION

I hereby declare that the Capstone Project entitled **"SafeGuard: AI-Powered Child Safety Platform"** submitted for the fulfillment of the requirements for the award of the degree of **Bachelor of Technology in Computer Science and Engineering** at **Lovely Professional University**, Phagwara, is a bona fide record of the work done by me under the supervision of **[Mentor Name]**, [Mentor Designation], School of Computer Science and Engineering, Lovely Professional University.

I further declare that the work reported in this project report has not been submitted and will not be submitted, either in part or in full, for the award of any other degree or diploma in this or any other Institute or University.

<br>
<br>
<br>

**Date:** [DD/MM/YYYY]  
**Place:** Phagwara, Punjab

<br>
<br>

**(Signature of Student)**  
**[Your Name]**  
**Reg. No.: [Your Reg No]**
