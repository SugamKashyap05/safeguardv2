
# ACKNOWLEDGEMENT

I would like to express my gratitude to my mentor, **[Mentor Name]**, for their invaluable guidance, encouragement, and support throughout the course of this project. Their insights and expertise have been instrumental in shaping this work.

I am also thankful to the **School of Computer Science and Engineering, Lovely Professional University**, for providing the necessary infrastructure and resources to carry out this project successfully.

Finally, I would like to thank my parents, friends, and peers for their constant encouragement and constructive feedback, which helped me overcome various challenges during the development of **SafeGuard**.

<br>
<br>

**[Your Name]**  
**Reg. No.: [Your Reg No]**
