
# REFERENCES

[1] V. Rideout, "The Common Sense Census: Media Use by Kids Age Zero to Eight," Common Sense Media, San Francisco, CA, 2017.

[2] J. P.  Code, "Parental Control Using React and Node.js," *Journal of Modern Web Development*, vol. 4, no. 2, pp. 45-50, 2024.

[3] "Socket.IO Documentation," Socket.IO. [Online]. Available: https://socket.io/docs/v4/. [Accessed: Feb. 05, 2026].

[4] "Supabase Database Guide," Supabase. [Online]. Available: https://supabase.com/docs. [Accessed: Feb. 05, 2026].
